export interface IAccessTokenPayload {
    id: number;
    email: string;
}